#include <stdio.h>

int main() {
   int i= 0;

    for(i = 150; i >= 0;) {
        printf("%d\n", i);
        i--;
    }
    while (i>0)
    
    return 0;
}
